# Integral-en-Java
Metodos de integración

Programa que me calcula una integral por:
-Metodo Rectangulo Izquierdo en Java
-Metodo Rectangulo Derecho en Java
-Metodo Trapecio en Java
-Metodo Simpson en Java

Explicación del código:https://www.youtube.com/watch?v=aGd6XN_g_Hg

Si tienes alguna pregunta puedes escribirnos a nuestro facebook: https://www.facebook.com/desarrollocod
